# 简介
移动平台部分包括 Android 和 iOS 部分，内容为 2016 年 XMan 课堂笔记。