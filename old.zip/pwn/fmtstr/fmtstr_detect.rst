格式化字符串漏洞检测
====================

这里推荐一个简单的工具\ `LazyIDA <https://github.com/L4ys/LazyIDA>`__\ 。基本的检测应该没有问题。
