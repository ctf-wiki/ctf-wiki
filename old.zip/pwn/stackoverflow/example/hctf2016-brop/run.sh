nohup ./deploy.sh &
