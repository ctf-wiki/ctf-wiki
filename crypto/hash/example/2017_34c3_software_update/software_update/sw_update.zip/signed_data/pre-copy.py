#!/usr/bin/python3

print("Preparing to copy data...")
