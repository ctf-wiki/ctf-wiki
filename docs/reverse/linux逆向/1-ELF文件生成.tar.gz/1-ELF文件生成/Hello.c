//main函数
int main(int argc, char const *argv[]) {
  //打印字符串Hello World并换行
  printf("Hello World\n");
  return 0;
}
